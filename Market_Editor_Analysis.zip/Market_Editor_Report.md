# DayZ Expansion Market Editor — Analysis Report

Source: https://dayzexpansion.com/tools/custom/market-manager
Tool version: v26.05.25.15
Captured: 2026-05-30T05:28:14.682Z

## 1. What the tool is
A browser-based, client-side editor for the DayZ Expansion mod's **Market** system. It lets server
admins import, edit, validate, and re-export the JSON files that define what traders sell/buy, at
what prices, and in what stock. All work happens locally in the browser (autosaved to localStorage);
nothing is uploaded to a server. Files can be imported/exported individually as .json or in bulk as a
.zip archive.

## 2. Two file types
The editor manages two kinds of JSON files, shown under the **Market** and **Traders** tabs.

### A) Market category files (type: "market")
Each file = one category of items (e.g. Ammo, Weapons, Food). Structure:

- m_Version       — file format version (e.g. 12)
- DisplayName     — name shown in the trader menu (often a localization key like
                    "#STR_EXPANSION_MARKET_CATEGORY_AMMO")
- Icon            — icon id shown in menu (e.g. "Deliver")
- Color           — ARGB hex tint for the category (e.g. "FBFCFEFF")
- IsExchange      — 0/1; marks the items as usable currency (exchange category)
- InitStockPercent— initial stock on server start, as % of max (e.g. 75)
- Items[]         — array of item rows

Each item row:
- ClassName         — the in-game item class
- MinPriceThreshold — buy price when stock is full (low)
- MaxPriceThreshold — buy price when stock is empty (high). Price floats between min/max based on stock.
- MinStockThreshold — restock floor
- MaxStockThreshold — restock ceiling
- SellPricePercent  — % of buy price paid when selling; -1 = use global default
- QuantityPercent   — quantity handling; -1 = use global default
- SpawnAttachments[]— classnames auto-attached when the item is purchased
- Variants[]        — classname variants grouped under this item

### B) Trader files (type: "trader")
Each file = one NPC merchant definition. Structure:

- m_Version              — format version (e.g. 13)
- DisplayName            — trader's display name (localization key)
- TraderIcon             — icon id (e.g. "Shotgun")
- Currencies[]           — item classnames accepted as payment (e.g. "expansionbanknotehryvnia")
- DisplayCurrencyValue   — 0/1 whether to display currency value
- DisplayCurrencyName    — optional currency label
- UseCategoryOrder       — 0/1; respect the explicit category ordering below
- Categories[]           — market category files this trader offers. An entry may carry a display-mode
                           suffix, e.g. "Assault_Rifles:1"
- Items{}                — per-item overrides keyed by classname
- MinRequiredReputation / MaxRequiredReputation — reputation gating
- RequiredFaction        — faction gating
- RequiredCompletedQuestID — quest gating (-1 = none)

#### Category display modes (the ":N" suffix)
- 0 = Buy only
- 1 = Buy & Sell
- 2 = Sell only
- 3 = Hidden

## 3. Editor features observed
- **Sidebar file list** with Market/Traders tabs, per-file item counts, and a file search box.
- **Import files / ZIP** (also drag & drop) and **Export** (single file or full ZIP archive).
- **Inline header editing**: DisplayName, Icon (dropdown), Color (ARGB hex + color swatch),
  InitStockPercent, Exchange (Yes/No).
- **Price Overview chart**: collapsible bar chart visualizing min/max price across all items in the file;
  per-item "View price curve" is available on each expanded row.
- **Item table**: columns ClassName, Min/Max Price, Min/Max Stock, Sell %, Qty %, with Add item,
  Bulk import, per-row duplicate/delete, and an expand arrow.
- **Expanded item row**: edit SpawnAttachments, Variants, and a live Summary (price/stock ranges,
  sell/qty defaults).
- **Trader editor**: Identity (DisplayName, TraderIcon, category order), Currency section (accepted
  payment classnames + display options), Requirements (reputation/faction/quest), and Category
  Assignments with checkboxes + drag-to-reorder and 0/1/2/3 display-mode filters.
- **Diagnostics / Issues panel**: flags inverted prices, duplicates, cross-file conflicts, missing
  dependencies, and missing DisplayName; clicking an entry jumps to the problem. It also surfaces
  *info* suggestions, e.g. "Optics needs Batteries (reflexoptic → battery9v …)".
- **Bulk rename** and **Global search** (Ctrl+Shift+F) across all files.
- **Clear Session**, **Fullscreen** (F11), built-in **tutorial** and **keyboard-shortcuts** overlay.
- **Autosave** to browser localStorage (key: market_editor_autosave); fully client-side.

## 4. Keyboard shortcuts
Undo Ctrl+Z · Redo Ctrl+Y · Export active file Ctrl+S · Import files Ctrl+O ·
Global search Ctrl+Shift+F · Toggle fullscreen F11 · Show shortcuts ? · Exit fullscreen Esc

## 5. How pricing works (in-game model the editor exposes)
A trader's live price for an item floats between MinPriceThreshold (lots in stock) and
MaxPriceThreshold (out of stock). Stock regenerates toward MaxStockThreshold over time, starting at
InitStockPercent of max. Selling pays SellPricePercent of the current buy price (or the global
default when set to -1). Items flagged IsExchange act as currency.

## 6. Typical workflow
1. Import your existing market/trader JSONs (or a ZIP of the whole expansion_market folder).
2. Edit categories, prices, stock, attachments, and trader assignments inline.
3. Watch the Diagnostics panel and resolve errors/conflicts.
4. Export the corrected files (single .json via Ctrl+S, or the full set as a ZIP) back to your server.

---
See findings.json for the exact captured JSON schemas and metadata, and the /screenshots notes file
for the captured UI states.
